const DjangoConfig = {
    apiUrl:`http://103.190.95.164:12002`,  
};

export default DjangoConfig;